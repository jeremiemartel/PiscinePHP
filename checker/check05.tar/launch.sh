mysql -uroot db_$USER <reset.sql && mysql db_$USER -uroot <exec.sql
