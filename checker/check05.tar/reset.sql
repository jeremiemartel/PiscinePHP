DROP DATABASE IF EXISTS db_jmartel;
source ex00/ex00.sql;
