#Path to your repo, with no / at the end
path="."

for file in "00" "01" "02" "03"
do
    cp ./resources/main_$file.php $path/ex$file/
    cp ./resources/main_$file.out $path/ex$file/
    if  [ ! $? -eq 0 ]
    then   
        exit
    fi
done

echo Successfully copied main files.

echo Trying to create symlinks
ln -s $path/ex00/Color.class.php $path/ex01/
ln -s $path/ex00/Color.class.php $path/ex02/
ln -s $path/ex00/Color.class.php $path/ex03/

ln -s $path/ex01/Vertex.class.php $path/ex02/
ln -s $path/ex01/Vertex.class.php $path/ex03/

ln -s $path/ex02/Vector.class.php $path/ex03/

echo Launching differences :

cd $path
for num in "00" "01" "02" "03"
do
    cd ex$num;
    php main_$num.php > myres
    diff myres main_$num.out
    cd ..
done
