#Path to your repo, with no / at the end
$path="."

rm -f $path/ex01/Color.class.php 
rm -f $path/ex02/Color.class.php 
rm -f $path/ex03/Color.class.php 
rm -f $path/ex02/Vertex.class.php
rm -f $path/ex03/Vertex.class.php
rm -f $path/ex03/Vector.class.php

rm -f ./ex0*/myres