php test1.php > myres
echo ---- ex05 ----
diff res myres
echo Test2 ex05
    php test2.php