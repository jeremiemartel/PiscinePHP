php test.php > myres
echo ---- ex04 ----
diff res myres
