echo ---- ex00 ----

php test.php > myres
diff res myres
