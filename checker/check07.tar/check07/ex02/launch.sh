php test.php > myres

echo ---- ex02 ----

diff res myres