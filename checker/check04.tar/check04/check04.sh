#!/bin/zsh
US=Okalmos
PASSWD=Tamer
HOST="http://e2r2p8.42.fr:8100/"

echo Creating user
echo -n "\t"
	curl -c cook.txt -d cook.txt -d login=$US -d passwd=$PASSWD -d submit=OK "$HOST/ex01/create.php"

echo Creating many users
echo -n "\t"
	curl -c cook.txt -d cook.txt -d login=asd -d passwd=$PASSWD -d submit=OK "$HOST/ex01/create.php"
echo -n "\t"
	curl -c cook.txt -d cook.txt -d login=asdw -d passwd=$PASSWD -d submit=OK "$HOST/ex01/create.php"
echo -n "\t"
	curl -c cook.txt -d cook.txt -d login=asdew -d passwd=$PASSWD -d submit=OK "$HOST/ex01/create.php"
echo -n "\t"
	curl -c cook.txt -d cook.txt -d login=asdsd -d passwd=$PASSWD -d submit=OK "$HOST/ex01/create.php"
echo -n "\t"
	curl -c cook.txt -d cook.txt -d login=aw -d passwd=$PASSWD -d submit=OK "$HOST/ex01/create.php"
echo -n "\t"
	curl -c cook.txt -d cook.txt -d login=asdds -d passwd=$PASSWD -d submit=OK "$HOST/ex01/create.php"

echo "WhoamI (should write error)"
echo -n "\t"
	curl -c cook.txt -b cook.txt  "$HOST/ex03/whoami.php"

echo "logging in"
echo -n "\t"
	curl -c cook.txt -d cook.txt  "$HOST/ex03/login.php?login=$US&passwd=$PASSWD"

echo "WhoamI (should write $US)"
echo -n "\t"
	curl -c cook.txt -b cook.txt  "$HOST/ex03/whoami.php"

echo "Logging out"
	curl -c cook.txt -b cook.txt  "$HOST/ex03/logout.php"

echo "WhoamI (should write error)"
echo -n "\t"
	curl -c cook.txt -b cook.txt  "$HOST/ex03/whoami.php"

echo "\n\n"

echo "Modifying pasword"
echo -n "\t"
	curl -c cook.txt -d cook.txt -d login=$US -d oldpw=$PASSWD -d newpw=new$PASSWD -d submit=OK "$HOST/ex02/modif.php"

echo "logging in with old password (should send error)"
echo -n "\t"
	curl -c cook.txt -d cook.txt  "$HOST/ex03/login.php?login=$US&passwd=$PASSWD"

echo "WhoamI (should write error)"
echo -n "\t"
	curl -c cook.txt -b cook.txt  "$HOST/ex03/whoami.php"

echo "logging in with new password"
echo -n "\t"
	curl -c cook.txt -d cook.txt  "$HOST/ex03/login.php?login=$US&passwd=new$PASSWD"

echo "WhoamI (should write $US)"
echo -n "\t"
	curl -c cook.txt -b cook.txt  "$HOST/ex03/whoami.php"

echo "Logging out"
	curl -c cook.txt -b cook.txt  "$HOST/ex03/logout.php"

echo "WhoamI (should write error)"
echo -n "\t"
	curl -c cook.txt -b cook.txt  "$HOST/ex03/whoami.php"
